export const environment = {
  apiUrl: 'https://boolean-api-server.fly.dev',
};
